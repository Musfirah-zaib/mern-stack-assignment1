const http = require('http');
const port = 8080;
const host = '192.168.0.104';
const generateOTP=require('./user_otp.js');
const generateOTP = require('./user_otp.js');
const server = http.createServer((req, res) => {
   if(req.url==='/api/user/otp' && method==='get'){
    const otp=generateOTP();
    res.end(`${otp}`);
   }
else{
    res.end(`invalid route`);   
}
    
});

server.listen(port, () => {
    console.log(`server is running on ip http://${host}:${port}`);
});

