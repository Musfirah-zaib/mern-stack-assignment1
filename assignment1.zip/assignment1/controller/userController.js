const User = require('../models/userModel');

const createUser = async (req, res) => {
  try {
    const { name, email, password, phone, dob, address } = req.body;

    const user = new User({ name, email, password, phone, dob, address });
    await user.save();

    res.status(201).json({ message: 'User created successfully' });
  } catch (err) {
    res.status(500).json({ error: 'Server Error', details: err.message });
  }
};

module.exports = { createUser };
