const http = require('http');
const port = 8080;
const host = '192.168.0.104';

// const server = http.createServer((req, res) => {
//     const name = 'musfirah zaib';
//     const rollNumber = "L1S23BSSE0107";
//     const date = new Date();
//     const msg = `<h3>profile info</h3> <br>
// <h4>name:${name}h4>
// <h4>roll number:${rollNumber}<h4>
// <h5> ip address:${host}</h5>
// <h6>date:${date.toString()}</h6>`

//     res.writeHead(200, { 'Content-Type': 'text/html' });
//     res.write(msg);
//     res.end();
// });


//qno2


const generateOTP = require('./user_otp.js');
const server = http.createServer((req, res) => {
   if(req.url==='/api/user/otp' && req.method==='GET'){
    const otp=generateOTP();
    
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(`<h1>Your OTP is: ${otp}</h1>`);
   }
else{
    res.writeHead(404, { 'Content-Type': 'text/html' });
    res.end(`<h2>Invalid Route</h2>`); 
}
    
});




server.listen(port, () => {
    console.log(`server is running on ip http://${host}:${port}`);
});

